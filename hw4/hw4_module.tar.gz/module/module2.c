#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>

struct my_data{
	int a,b,c;
};

struct my_student_num{
	int thousand, hundred, ten, unit;
};

extern long newcall(struct my_data *block);
extern long mynew_function(const int num, struct my_student_num *data);

int calldev_init(void){
	struct my_data data;
	printk(KERN_INFO "Embedded SoftWare 2017\n");
	data.a=7;
	data.b=3;

	printk(KERN_INFO "sysc# = %ld\n", newcall(&data));

	printk(KERN_INFO "a + b = %d\n", data.a);
	printk(KERN_INFO "a - b = %d\n", data.b);
	printk(KERN_INFO "a %% b = %d\n", data.c);

	return 0;
}

int call_mynew_funtion(void){

	const int num = 1593;
	struct my_student_num data;

	printk(KERN_INFO "Embedded SoftWare 2021\n");
	printk(KERN_INFO "sysc# = %ld\n", mynew_function(num, &data));	
	printk(KERN_INFO "\n=================assignment 4=================\n");
	printk(KERN_INFO "Thousands = %d / hundreds = %d / tens = %d / units = %d\n", data.thousand, data.hundred, data.ten, data.unit);
	return 0;
}

void calldev_exit( void ) { }
module_init ( call_mynew_funtion );
module_exit ( calldev_exit );
MODULE_LICENSE("Dual BSD/GPL");
