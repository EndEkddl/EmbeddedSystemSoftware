#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>

struct my_data{
	int a,b,c;
};

struct my_student_num{
	int thousand;
	int hundred;
	int ten;
	int unit;
};

long newcall(struct my_data *data){
	int a, b;

	a=data->a;
	b=data->b;

	data->a=a+b;
	data->b=a-b;
	data->c=a%b;

	return 313;
}

int funcdev_init( void ) {
	return 0;
}
void funcdev_exit( void ) { }

long mynew_function(const int num, struct my_student_num* data){

	int tmp = num;
	data->thousand = tmp/1000;
	tmp %= 1000;
	data->hundred = tmp/100;
	tmp %= 100;
	data->ten = tmp/10;
	tmp %= 10;
	data->unit = tmp;
	
	return 313;
}

EXPORT_SYMBOL( newcall );
EXPORT_SYMBOL(mynew_function);

module_init ( funcdev_init );
module_exit ( funcdev_exit );
MODULE_LICENSE("Dual BSD/GPL");
