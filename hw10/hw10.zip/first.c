extern int first(int x,int y);
extern int myFunc(int x, int y);

int first(int x, int y)
{
	return x + y;
}

int myFunc(int x, int y){
	return x * y;
}
