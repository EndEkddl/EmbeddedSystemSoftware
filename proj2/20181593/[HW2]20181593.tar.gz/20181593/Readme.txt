PROJ2 : Timer device driver & test application program

MAJOR_NUMBER : 242
DEVICE_NAME : dev/dev_driver


make : 
make clean :
make push : transfer files for the host to the board.
