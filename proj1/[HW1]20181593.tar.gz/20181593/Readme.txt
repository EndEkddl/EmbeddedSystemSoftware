PROJ1 : Clock, Counter, Text editor, Draw board

실행 파일 이름 : 20181593

make : 실행 파일과 .o 코드를 생성
make clean : 실행 파일과 .o 코드를 지움
make push : host의 파일을 board로 전송